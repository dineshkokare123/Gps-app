package com.example.findmybus;

/**
 * Created by Jeet on 29-Apr-17.
 */

public interface OnSeatSelected {
    void onSeatSelected(int count);
}
