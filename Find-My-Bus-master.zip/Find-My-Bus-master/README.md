# FindMyBus

FindMyBus provides facilities like real time tracking of public transport, Seat availability and many more.

FindmyBus uses the current position of the vehicle for calculation of the arrival time from particular source to destination. Also, we have used current position to determine the whole journey time. We get the current position of the vehicle using the GPS fitted in the vehicle. Vehicle reservation is used to check the current occupied seats and reservation of the available seats. The capacitive sensor is used to check the availability of the seats. This information is sent to the server through GPRS and used for further calculations in the system. Application is in current BETA Phase.
